webpackHotUpdate("static/development/pages/index.js",{

/***/ "./pages/Amazonlogin.js":
/*!******************************!*\
  !*** ./pages/Amazonlogin.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Demo; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Amazon_Social__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Amazon/Social */ "./pages/Amazon/Social.js");
/* harmony import */ var _Amazon_userCard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Amazon/userCard */ "./pages/Amazon/userCard.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! axios */ "../node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _public_amazon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../public/amazon */ "./public/amazon.js");
/* harmony import */ var _public_google__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../public/google */ "./public/google.js");






var __jsx = react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement;
 // import insta from './logos/amazon_logo.png';

 // import google from './logos/google_logo.png'





var image = {
  logo: {
    position: 'absolute',
    top: '15px',
    left: '30px',
    cursor: 'pointer'
  },
  logo1: {
    position: 'absolute',
    top: '15px',
    left: '155px',
    cursor: 'pointer'
  },
  logo2: {
    position: 'absolute',
    top: '15px',
    left: '285px',
    cursor: 'pointer'
  },
  logo3: {
    position: 'absolute',
    top: '15px',
    left: '415px',
    cursor: 'pointer'
  },
  logo4: {
    position: 'absolute',
    top: '15px',
    left: '545px',
    cursor: 'pointer'
  },
  loginwith: {
    position: 'absolute',
    top: '150px',
    left: '150px'
  }
};

var Demo =
/*#__PURE__*/
function (_Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(Demo, _Component);

  function Demo(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Demo);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(Demo).call(this, props));
    _this.state = {
      logged: false,
      user: {},
      shopURL: 'sociallog.myshopify.com',
      currentProvider: ''
    };
    _this.nodes = {};
    _this.onLoginSuccess = _this.onLoginSuccess.bind(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this));
    _this.onLoginFailure = _this.onLoginFailure.bind(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this));
    _this.onLogoutSuccess = _this.onLogoutSuccess.bind(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this));
    _this.onLogoutFailure = _this.onLogoutFailure.bind(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this));
    _this.logout = _this.logout.bind(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__["default"])(_this));
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Demo, [{
    key: "setNodeRef",
    value: function setNodeRef(provider, node) {
      if (node) {
        this.nodes[provider] = node;
      }
    }
  }, {
    key: "onLoginSuccess",
    value: function onLoginSuccess(user) {
      var postData = [{
        "customer": {
          "first_name": user._profile.firstName,
          "last_name": user._profile.lastName,
          "email": user._profile.email
        }
      }];
      var credentials = '75ccaaf765b4e78631acd66f0df9220c';
      var basicAuth = 'Basic ' + credentials;
      console.log(user);
      console.log(postData);
      axios__WEBPACK_IMPORTED_MODULE_9___default.a.post('https://sociallog.myshopify.com/admin/api/2019-10/customers.json', postData, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'X-Shopify-Access-Token': credentials
        }
      }).then(function (response) {
        console.log('Ok', response);
      }).catch(function (error) {
        console.log('not Ok', error);
      });
      this.setState({
        logged: true,
        currentProvider: user._provider,
        user: user
      });
    }
  }, {
    key: "onLoginFailure",
    value: function onLoginFailure(err) {
      console.error(err);
      this.setState({
        logged: false,
        currentProvider: '',
        user: {}
      });
    }
  }, {
    key: "onLogoutSuccess",
    value: function onLogoutSuccess() {
      this.setState({
        logged: false,
        currentProvider: '',
        user: {}
      });
    }
  }, {
    key: "onLogoutFailure",
    value: function onLogoutFailure(err) {
      console.error(err);
    }
  }, {
    key: "logout",
    value: function logout() {
      var _this$state = this.state,
          logged = _this$state.logged,
          currentProvider = _this$state.currentProvider;

      if (logged && currentProvider) {
        this.nodes[currentProvider].props.triggerLogout();
      }
    }
  }, {
    key: "render",
    value: function render() {
      var children;

      if (this.state.logged) {
        children = __jsx(_Amazon_userCard__WEBPACK_IMPORTED_MODULE_8__["default"], {
          user: this.state.user,
          logout: this.logout
        });
      } else {
        children = [__jsx(_Amazon_Social__WEBPACK_IMPORTED_MODULE_7__["default"], {
          provider: "facebook",
          appId: "743738122718119",
          onLoginSuccess: this.onLoginSuccess,
          onLoginFailure: this.onLoginFailure,
          onLogoutSuccess: this.onLogoutSuccess,
          getInstance: this.setNodeRef.bind(this, 'facebook'),
          key: 'facebook'
        }, __jsx("img", {
          style: image.logo,
          src: "https://i.pinimg.com/originals/58/f4/72/58f4723d8f23906bdcb058604075ad2a.png",
          title: "facebook login",
          alt: "facebook",
          height: "150px",
          width: "150px"
        })), __jsx(_Amazon_Social__WEBPACK_IMPORTED_MODULE_7__["default"], {
          provider: "google",
          appId: "555371152154-faiudnv4deckojvcuqsh2kdpf5obe12u.apps.googleusercontent.com",
          onLoginSuccess: this.onLoginSuccess,
          onLoginFailure: this.onLoginFailure,
          onLogoutSuccess: this.onLogoutSuccess,
          onLogoutFailure: this.onLogoutFailure,
          getInstance: this.setNodeRef.bind(this, 'google'),
          key: 'google'
        }, __jsx(_public_google__WEBPACK_IMPORTED_MODULE_11__["default"], null)), __jsx(_Amazon_Social__WEBPACK_IMPORTED_MODULE_7__["default"], {
          provider: "amazon",
          appId: "amzn1.application-oa2-client.0623170e36984f82a8b4ed9b1230a1cb",
          onLoginSuccess: this.onLoginSuccess,
          onLoginFailure: this.onLoginFailure,
          onLogoutSuccess: this.onLogoutSuccess,
          getInstance: this.setNodeRef.bind(this, 'amazon'),
          key: 'amazon'
        }, __jsx(_public_amazon__WEBPACK_IMPORTED_MODULE_10__["default"], null)), __jsx("h5", {
          style: image.loginwith
        }, "or login with")];
      }

      return children;
    }
  }]);

  return Demo;
}(react__WEBPACK_IMPORTED_MODULE_6__["Component"]);



/***/ })

})
//# sourceMappingURL=index.js.56037e4331ac6c2d1e7a.hot-update.js.map