import React,{Component} from 'react';
import './App.css';

import "./App.css";
import Demo from './Amazonlogin';

class Popup1 extends Component {
  render(){
  return (
    <div className="App1">
      <header className="App-header1">
   
        
      <Demo />
      </header>
    </div>
  );
}
}
export default Popup1;
